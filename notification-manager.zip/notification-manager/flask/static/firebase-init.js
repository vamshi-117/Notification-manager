// static/firebase-init.js

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBcdgkzy7SSUTeU3mW3Y_XK3qJa8xmepdA",
  authDomain: "nmanager-4f504.firebaseapp.com",
  projectId: "nmanager-4f504",
  storageBucket: "nmanager-4f504.appspot.com",
  messagingSenderId: "363364443490",
  appId: "1:363364443490:web:05ebc9b78218e9e89ff83b",
  measurementId: "G-CK7BFJH8VG"
};

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  
  const messaging = firebase.messaging();
  
  async function registerServiceWorker() {
    try {
      const serviceWorkerRegistration = await navigator.serviceWorker.register('../firebase-messaging-sw.js', {
        scope: '/firebase-cloud-messaging-push-scope'
      });
      console.log('Service Worker registered successfully:', serviceWorkerRegistration);
    } catch (error) {
      console.error('Service Worker registration failed:', error);
    }
  }
  
  // Request permission to send notifications
  async function requestNotificationPermission() {
    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        console.log('Notification permission granted.');
        const token = await messaging.getToken({ vapidKey: 'BObW4GIgZs_c72x08k7Sy4T3rpY5Uzku9_9LRRd0rNKNLulOc_jwpVJ-PMLxwpyM9x5yxgT245lo9ysSO9BSmgE' });
        console.log('FCM Token:', token);
      } else {
        console.log('Unable to get permission to notify.');
      }
    } catch (error) {
      console.error('An error occurred while retrieving token:', error);
    }
  }
  
  // Register the service worker and request notification permission
  registerServiceWorker();
  requestNotificationPermission();
  